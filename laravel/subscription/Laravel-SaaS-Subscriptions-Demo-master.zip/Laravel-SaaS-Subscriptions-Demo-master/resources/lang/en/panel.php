<?php

return [
    'site_title' => 'Laravel Subscriptions',
];
